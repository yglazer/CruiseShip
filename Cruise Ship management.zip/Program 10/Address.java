/*-street: String
-city: String
-state: String
-zipcode: String
+Address(String street, String city, String state, String zip)
+getStreet(): String
+getCity(): String
+getState(): String
+getZip(): String
+toString(): String
*/
import java.util.*;
public class Address{
	/*Fields*/
	private String street;
	private String city;
	private String state;
	private String zipcode;
	/*constructor accepts all fields*/

	public Address(String street,String city, String state,String zipcode) {
		this.street=street;
		this.city=city;
		this.state=state;
		this.zipcode=zipcode;
	}
	/*copy constructor was not on uml
	 * but I thought I need it*/
	public Address(Address add) {
		this.street=add.street;
		this.city=add.city;
		this.state=add.state;
		this.zipcode=add.zipcode;
	}
	/*getters of all fields*/
	public String getStreet() {
		return street;
	}
	public String getCity() {
		return city;
	}
	public String getState() {
		return state;
	}
	public String getZipcode() {
		return zipcode;
	}
	/*toString method*/
	@Override
	public String toString() {
		StringBuilder sb= new StringBuilder();
		
		sb.append("Street: "+street);
		sb.append("\nCity: "+city);
		sb.append("\nState: "+state);
		sb.append("\nZipcode: "+zipcode);
		String sbString= sb.toString();
		return sbString;
	}
	
	
}