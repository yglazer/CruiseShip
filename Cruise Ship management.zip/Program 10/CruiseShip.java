import java.util.*;
public class CruiseShip extends Ship{
	private int maxPassengers;
	private ArrayList<Passenger> passengers = new ArrayList<Passenger>();
	
	//Constructors
	public CruiseShip(String name,int year,int maxPassengers,ArrayList<Passenger> passengers) {
		super(year,name);
		if(maxPassengers<0) {
			this.maxPassengers=0;}
		else{
			this.maxPassengers=maxPassengers;}
		this.passengers=passengers;
	
	}
	public CruiseShip(String name,int year,int maxPassengers) {
		super(year,name);
		if(maxPassengers<0) {
			this.maxPassengers=0;}
		else{
			this.maxPassengers=maxPassengers;}
		
	
	}
	
	public CruiseShip(int maxPassengers) {
		this.maxPassengers=maxPassengers;
		
	}
	public CruiseShip(int maxPassengers,ArrayList<Passenger> passengers) {
		this.maxPassengers=maxPassengers;
		this.passengers= passengers;
	}
	public CruiseShip(ArrayList<Passenger> passengers) {
		this.maxPassengers=0;
		this.passengers= passengers;
	}
	//Copy constructor
	public CruiseShip(CruiseShip copy) {
		super(copy.getYear(),copy.getName());
		this.maxPassengers=copy.maxPassengers;
		this.passengers=copy.passengers;
	
	}
	//Getters and Setters
	public void setMaxPassengers(int maxPassengers) {
		this.maxPassengers=maxPassengers;
	}
	public int getMaxPassengers() {
		return maxPassengers;
	}
	public void setPassengers(ArrayList<Passenger> passengers) {
		this.passengers=passengers;
	}
	//deep copy of passenger arraylist
	public ArrayList<Passenger> getPassengerArray(){
		ArrayList<Passenger> returnArrayPassengers = new ArrayList<Passenger> ();
		for(Passenger p:passengers) {
			returnArrayPassengers.add(new Passenger(p));}
		return returnArrayPassengers;
	}
	//add passenger Method
	public void addPassenger(Passenger p) throws ShipFullException, PassengerExistsException {
		boolean isFound = passengers.contains(p);
		if(maxPassengers<=passengers.size()) {
			ShipFullException e = new ShipFullException();
			throw e;
		}
		else if (isFound==true) {
			PassengerExistsException ex=new PassengerExistsException();
			throw ex;
		}
		else {
			passengers.add(p);
		}
	}
	
	//toString method
	@Override
	public String toString() {
	
			StringBuilder sb= new StringBuilder ();
			sb.append("Ship Name: "+this.getName());
			sb.append(" Year Built: "+this.getYear());
			sb.append("\nMax Passengers: "+maxPassengers);
			sb.append("\nPassengers: "+passengers+"\n");
			
			String sbString=sb.toString();
			return sbString;
		}
	}
	
	
