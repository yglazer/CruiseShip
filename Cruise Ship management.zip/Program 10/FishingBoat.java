public class FishingBoat extends Ship{
	//Fields
	double rentalPrice;
	//Constructors
	public FishingBoat() {
		rentalPrice=0000;
		
	}
	public FishingBoat(String name,int year, double rentalPrice) {
		super(year,name);
		this.rentalPrice=rentalPrice;
	}
	public FishingBoat(double rentalPrice) {
		this.rentalPrice=rentalPrice;
	}
	//copy constructor
	public FishingBoat(FishingBoat copy) {
		super(copy.getYear(),copy.getName());
		this.rentalPrice=copy.rentalPrice;
	}
	//Getters and Setters
	public double getPrice() {
		return rentalPrice;
	}
	public void setPrice(double rentalPrice) {
		this.rentalPrice=rentalPrice;
	}
	public void setSuperName(String name) {
		super.setName(name);
	}
	public void setSuperYear(int year) {
		super.setYear(year);
	}
	public String getSuperName() {
		return super.getName();
	}
	public int getSuperYear() {
		return super.getYear();
	}
	//toString
	@Override
	public String toString() {
			StringBuilder sb= new StringBuilder ();
			sb.append("Ship Name:"+super.getName());
			sb.append("\nPrice for Rental:"+this.rentalPrice);
			String sbString=sb.toString();
			return sbString;
		
		}
	
}