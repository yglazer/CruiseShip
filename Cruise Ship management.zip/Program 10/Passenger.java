import java.time.*;
public class Passenger extends Person{
	/*Fields*/
	private String passportID;
	private int luggagePieces;
	/*Constructors*/
	public Passenger(String firstName, String lastName, Gender gender, Address addr,String birthdate, String passportID, int luggage) {
		super(firstName,lastName,gender,addr,birthdate);
		this.passportID=passportID;
		this.luggagePieces=luggage;
	}
	//copy constructor
	public Passenger(Passenger p) {
		super(p.getFirstName(),p.getLastName(),p.getGender(),p.getAddress(),p.getBirthdate());
		this.passportID=p.passportID;
		this.luggagePieces=p.luggagePieces;
	}
	//equals based on passportID
	public boolean equals(Passenger p) {
		if (passportID==p.passportID) {
			return true;
		}
		for(int i=0;i<passportID.length();i++ ) {
			if (passportID.charAt(i)!=p.passportID.charAt(i)) {
			return false;
			}
		}return true; 
	}
	//toString
	@Override
	public String toString() {
		StringBuilder sb= new StringBuilder ();
		sb.append(super.toString());
		sb.append("\nPassport ID:"+passportID);
		sb.append("\nLuggage Pieces:"+luggagePieces);
		String sbString=sb.toString();
		return sbString;
	}
	
}

