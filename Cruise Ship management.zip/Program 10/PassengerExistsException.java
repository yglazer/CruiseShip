
	public class PassengerExistsException extends Exception{
		public PassengerExistsException() {
			super(" Passenger is already on board. ");
		}

	}


