


import java.time.LocalDate;
public class Person{
	/*fields*/
	private String firstName;
	private String lastName;
	private Gender gender;
	private LocalDate birthdate;
	private Address address;
	
	
	/*Constructors*/
	public Person(String f, String l, Gender g, Address add, String birthdate) {
		firstName=f;
		lastName=l;
		gender=g;
		address=new Address(add);
		LocalDate bday = LocalDate.parse(birthdate);
		this.birthdate=bday;
	}
	public Person(String f, String l, Gender g, String s, String c, String state, String zip, String birthdate) {
		firstName=f;
		lastName=l;
		gender=g;
		address=new Address(s,c,state,zip);
		LocalDate bday = LocalDate.parse(birthdate);
		this.birthdate=bday;
	}
	public Person(String f, String l, Gender g, Address add, LocalDate birthdate) {
		firstName=f;
		lastName=l;
		gender=g;
		address=new Address(add);
		this.birthdate=birthdate;
}
	//Copy constructor
	public Person(Person p) {
		/*this(p.firstName,p.lastName,p.gender,p.address,p.birthdate);*/
		this.firstName=p.firstName;
		this.lastName=p.lastName;
		this.gender=p.gender;
		this.address= new Address(p.address);
		this.birthdate=p.birthdate;
	}
	//Getters and Setters
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getFirstName() {
		return firstName;
	}
	public Gender getGender() {
		return gender;
	}
	public LocalDate getBirthdate() {
		return birthdate;
	}
	//equals based on firstName, lastName, and birthdate
	//I don't want to get a null pointer exception
	public boolean equals(Person p) {
		if(this==p) {
			return true;
		}
		if(p==null) {
			return false;
		}
		if (getClass() != p.getClass()) {
			return false;
		}
		if (this.firstName == null) {
			if(p.firstName != null) {
				return false;
			}
			else if (!this.firstName.equals(p.firstName)) {
			return false;
		}}
			if (this.lastName == null) {
				if(p.lastName != null) {
					return false;
				}
				else if (!this.lastName.equals(p.lastName)) {
			return false;
		}}
				if (this.birthdate == null) {
					if(p.birthdate != null) {
						return false;
					}
				
				else if (!this.birthdate.equals(p.birthdate)) {
			return false;
				}}
				return true;
	}
	//toString
	@Override
	public String toString() {
		StringBuilder sb= new StringBuilder ();
		sb.append("\nFirst Name: "+firstName);
		sb.append("\nLast Name: "+lastName);
		sb.append("\nGender: "+gender);
		sb.append("\nAddress: "+address);
		sb.append("\nBirthdate: "+birthdate);
		String sbString=sb.toString();
		return sbString;
	}
}

