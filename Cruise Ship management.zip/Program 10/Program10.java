import java.util.*;

public class Program10 {
	public static void main(String[]args) {
		Scanner keyboard= new Scanner(System.in);
		ArrayList <CruiseShip> csarray= new ArrayList<>(); 
		ArrayList <FishingBoat> fbarray= new ArrayList<>();
		int choice=0;
		while(choice!=5)
			{System.out.print("\nMenu\n----\n1.Create Cruise Ship\n2.Create Fishing Boat \n3.Print all cruise ships \n4.Print all fishing boats");
		choice= keyboard.nextInt();
		if (choice==1) {
			createCS(csarray,keyboard);
		}
		else if (choice==2) {
			createFB(fbarray,keyboard);
		}
		else if(choice==3) {
			System.out.print(csarray);
			}
		else if(choice==4) {
			System.out.print(fbarray);
		}
		}
	}
	public static void createCS (ArrayList<CruiseShip>csarray,Scanner keyboard) {
		keyboard.nextLine();
		System.out.println("\nWhat is the name of the ship?");
		String name=keyboard.nextLine();
		System.out.println("What year was it built?");
		int year= keyboard.nextInt();
		System.out.println("What is the max amount of passengers for this ship?");
		int max=keyboard.nextInt();
		ArrayList <Passenger> parray= new ArrayList<>();
		CruiseShip cruiseship= new CruiseShip(name,year,max,parray);
		csarray.add(cruiseship);
		createPass(keyboard,cruiseship);
		
		
	}
	public static void createFB(ArrayList<FishingBoat>fbarray,Scanner keyboard) {
		keyboard.nextLine();
		System.out.println("\nWhat is the name of the ship?");
		String name=keyboard.nextLine();
		System.out.println("What year was it built?");
		int year= keyboard.nextInt();
		System.out.println("What is the rental price?");
		double price=keyboard.nextDouble();
		FishingBoat fishingboat=new FishingBoat(name,year,price);
		fbarray.add(fishingboat);
	}
	public static void createPass(Scanner keyboard,CruiseShip cruiseship) {
		keyboard.nextLine();
		String again="y";
		System.out.println("Do you want to add a passenger?(y/n)");
		again=keyboard.nextLine();
		while(again.charAt(0)=='y'||again.charAt(0)=='Y') {
			System.out.println("First Name?");
			String fname= keyboard.nextLine();
			System.out.println("Last Name?");
			String lname= keyboard.nextLine();
			System.out.println("Gender? M or F");
			String gender=keyboard.nextLine();
			while(gender.charAt(0)!='M'&&gender.charAt(0)!='F') {
				System.out.println("Bad input! please choose M or F");
				System.out.println("Gender? M or F");
				gender=keyboard.nextLine();
			}
			Gender g;
			if (gender.equals("M")){
				g=Gender.M;
			}
			else {
				g=Gender.F;
			}
			System.out.println("street address?");
			String street=keyboard.nextLine();
			System.out.println("city?");
			String city=keyboard.nextLine();
			System.out.println("state?");
			String state=keyboard.nextLine();
			System.out.println("zipcode?");
			String zipcode=keyboard.nextLine();
			Address add=new Address(street,city,state,zipcode);
			System.out.println("Birthdate?(yyyy-mm-dd)");
			String birthdate=keyboard.nextLine();
			System.out.println("passport ID?");
			String pass=keyboard.nextLine();
			System.out.println("Amount of luggage peices?");
			int luggage=keyboard.nextInt();
			while (luggage<0) {
				System.out.println("Can't be a negative abount please try again");
				System.out.println("Amount of luggage peices?");
				luggage=keyboard.nextInt();
			}
			Passenger p = new Passenger(fname,lname,g,add,birthdate,pass,luggage);
			try {
				cruiseship.addPassenger(p);
			} catch (ShipFullException e) {
				System.out.println("Sorry the ship is full. Try again tommorow");
			}catch(PassengerExistsException ex) {
				System.out.println("That passenger already exists in our system");
			}
			System.out.println("Passenger added");
			keyboard.nextLine();
			System.out.println("Do you want to add a passenger?(y/n)");
			again=keyboard.nextLine();
			
			
			
		}
		
	}
}