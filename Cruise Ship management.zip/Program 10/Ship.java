public class Ship{
	
	//Fields
	private String name;
	private int year;
	
	//constructors
	public Ship() {
		year=0;
		name="";
	}
	public Ship(int year,String name) {
		this.year=year;
		this.name=name;
	}
	public Ship(int year) {
		this.year=year;
		this.name="";
	}
	public Ship(String name) {
		this.name=name;
		this.year=0;
	}
	public Ship(Ship copy) {
		this.name=copy.name;
		this.year=copy.year;
	}
	//Getters and setters
	public int getYear() {
		return this.year;
	}
	public void setYear(int year) {
		this.year=year;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name=name;
	}
	//toString method using string builder
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Ship Name: " + name);
		sb.append("\nYear ship was built: " + year);
		return sb.toString();
	}
	
}
