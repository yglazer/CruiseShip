
public class ShipFullException extends Exception{
	public ShipFullException() {
		super("Sorry no new passengers can be added, ship is full");
	}

}
